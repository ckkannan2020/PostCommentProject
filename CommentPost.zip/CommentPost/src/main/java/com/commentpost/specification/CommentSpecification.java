package com.commentpost.specification;


import java.lang.reflect.Field;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Expression;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;

import org.springframework.data.jpa.domain.Specification;

import com.commentpost.model.Comments;





public class CommentSpecification implements Specification<Comments> {
	
	Comments comments = new Comments();
	
	private String searchValue;
	
	public CommentSpecification (){
		
	}
	

	public void add(String value) {
		searchValue = value;
	}
	
	
	@Override
	public Predicate toPredicate(Root<Comments> root, CriteriaQuery<?> query, CriteriaBuilder builder) {
		List<Predicate> predicates = new ArrayList<>();
		
		if (searchValue != null && !searchValue.isEmpty()) 
		{
			
			for (Field field : comments.getClass().getDeclaredFields()) {
				String name = field.getName();
				if (!name.equals("serialVersionUID")) {
					
					
					if (name.equals("id") || name.equals("postId")) {
						Expression<String> filterKeyExp = root.get(field.getName()).as(String.class);
						filterKeyExp = builder.lower(filterKeyExp);				
						predicates.add(builder.or(builder.like(filterKeyExp, "%"+searchValue.trim().toLowerCase()+"%")));
					
					}
					else
						predicates.add(builder.or(builder.like(root.get(field.getName()), "%"+searchValue+"%")));						
				}
				      				      
			}							
		}
		return builder.or(predicates.toArray(new Predicate[0]));
	}	

}
