package com.commentpost.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

import com.commentpost.model.Comments;


public interface CommentRepository extends JpaRepository<Comments,Integer>,JpaSpecificationExecutor<Comments>{
	
	
	List<Comments> findByPostId(Integer id);
	

}
