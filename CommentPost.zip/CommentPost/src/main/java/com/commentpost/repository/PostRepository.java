package com.commentpost.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.commentpost.model.Posts;

public interface PostRepository extends JpaRepository<Posts,Integer>{
	
	Posts findByPostId(Integer id);

	
}
