package com.commentpost.bean;

import java.util.List;

public class RestParams {
	
	
	private List<RestCommentParams> restCommentParams;
	
	private List<RestPostParams> restPostParams;

	public List<RestCommentParams> getRestCommentParams() {
		return restCommentParams;
	}

	public void setRestCommentParams(List<RestCommentParams> restCommentParams) {
		this.restCommentParams = restCommentParams;
	}

	public List<RestPostParams> getRestPostParams() {
		return restPostParams;
	}

	public void setRestPostParams(List<RestPostParams> restPostParams) {
		this.restPostParams = restPostParams;
	}
	
	
	
	

}
