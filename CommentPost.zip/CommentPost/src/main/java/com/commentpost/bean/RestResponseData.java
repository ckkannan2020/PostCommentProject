package com.commentpost.bean;



public class RestResponseData extends RestError{
	
	private Object data;

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	public RestResponseData() {
		super();
		// TODO Auto-generated constructor stub
	}
	

}
