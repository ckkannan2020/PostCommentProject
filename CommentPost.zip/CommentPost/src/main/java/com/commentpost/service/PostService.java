package com.commentpost.service;


import com.commentpost.bean.RestParams;
import com.commentpost.bean.RestPostId;
import com.commentpost.bean.RestPostParams;
import com.commentpost.bean.RestResponseData;

public interface PostService {

	public RestResponseData listPosts(Integer postId);
	
	
	public RestResponseData listPostsAll();
	
	public RestResponseData insertPost(RestParams params);

}
