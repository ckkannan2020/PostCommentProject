package com.commentpost.service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.commentpost.bean.RestCommentParams;
import com.commentpost.bean.RestParams;
import com.commentpost.bean.RestPostId;
import com.commentpost.bean.RestPostParams;
import com.commentpost.bean.RestPostResponse;
import com.commentpost.bean.RestResponseData;
import com.commentpost.model.Comments;
import com.commentpost.model.Posts;
import com.commentpost.repository.CommentRepository;
import com.commentpost.repository.PostRepository;


@Service
public class PostServiceImpl implements PostService{
	
	@Autowired
	PostRepository postRepository;
	
	@Autowired
	CommentRepository commentRepository;
	
	public RestResponseData listPosts(Integer params) {
		
		RestResponseData response = new RestResponseData();
		RestPostResponse postResponse; 
		List<RestPostResponse> postResponseLs = new ArrayList<>();
    	
    	if (params != null) {
    		Posts post = postRepository.findByPostId(params);
    		postResponse = new RestPostResponse();
    		List<Comments> commentLs = commentRepository.findByPostId(params);    		
    		postResponse.setPost_id(post.getPostId());
    		postResponse.setPost_title(post.getTitle());
    		postResponse.setPost_body(post.getBody());
    		postResponse.setTotal_number_of_comments(commentLs.size());
    		response.setData(postResponse);
    	} 

    	
    	
		
		return response;
		
	}
	
	
	public RestResponseData listPostsAll() {
		
		RestResponseData response = new RestResponseData();
		RestPostResponse postResponse; 
		List<RestPostResponse> postResponseLs = new ArrayList<>();
    	
    	
    		List<Posts> postLs = postRepository.findAll();
    		Iterator<Posts> it = postLs.iterator();
    		
    		while(it.hasNext()) {
    			Posts post = it.next();
    			List<Comments> commentLs = commentRepository.findByPostId(post.getPostId());
    			postResponse = new RestPostResponse();
        		postResponse.setPost_id(post.getPostId());
        		postResponse.setPost_title(post.getTitle());
        		postResponse.setPost_body(post.getBody());
        		postResponse.setTotal_number_of_comments(commentLs.size());   
        		postResponseLs.add(postResponse);
    		}

    		postResponseLs.sort(Comparator.comparing(RestPostResponse::getTotal_number_of_comments).reversed());
    		
    		response.setData(postResponseLs);
    	
    	
    	
		
		return response;
		
	}
		
	
	public RestResponseData insertPost(RestParams params) {
		
		RestResponseData res = new RestResponseData();
		
		if (params != null) {
			List<RestPostParams> commentLs= params.getRestPostParams();
			
			Iterator<RestPostParams> it = commentLs.iterator();
			
			while (it.hasNext()) {
				RestPostParams param = it.next();
				Posts post = new Posts();
				post.setPostId(Integer.parseInt(param.getId()));
				post.setUserId(Integer.parseInt(param.getUserId()));
				post.setTitle(param.getTitle());
				post.setBody(param.getBody());
				postRepository.save(post);
			}
		}
		
		
		return res;
		
	}

}
