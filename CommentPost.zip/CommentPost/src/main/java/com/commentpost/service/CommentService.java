package com.commentpost.service;

import com.commentpost.bean.RestCommentParams;
import com.commentpost.bean.RestParams;
import com.commentpost.bean.RestResponseData;

public interface CommentService {
	
	public RestResponseData listComment(String param);
	
	public RestResponseData insertComment(RestParams params);
		
	
	public RestResponseData listCommentAll();
}
