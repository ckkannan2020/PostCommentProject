package com.commentpost.service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.commentpost.bean.RestCommentParams;
import com.commentpost.bean.RestParams;
import com.commentpost.bean.RestPostResponse;
import com.commentpost.bean.RestResponseData;
import com.commentpost.model.Comments;
import com.commentpost.model.Posts;
import com.commentpost.repository.CommentRepository;
import com.commentpost.specification.CommentSpecification;


@Service
public class CommentServiceImpl implements CommentService {
	
	@Autowired
	CommentRepository commentRepository;
	
	public RestResponseData insertComment(RestParams params) {
		
		RestResponseData res = new RestResponseData();
		
		if (params != null) {
			List<RestCommentParams> commentLs= params.getRestCommentParams();
			
			Iterator<RestCommentParams> it = commentLs.iterator();
			
			while (it.hasNext()) {
				RestCommentParams param = it.next();
				Comments comment = new Comments();
				comment.setPostId(Integer.parseInt(param.getPostId()));
				comment.setId(Integer.parseInt(param.getId()));
				comment.setName(param.getName());
				comment.setEmail(param.getEmail());
				comment.setBody(param.getBody());				
				commentRepository.save(comment);
			}
		}
		
		
		return res;
		
	}

	
	public RestResponseData listCommentAll() {
		
		RestResponseData response = new RestResponseData();
		List<Comments> commentLs = commentRepository.findAll();	
		
		commentLs.sort(Comparator.comparing(Comments::getId));		
		
		response.setData(commentLs);		
		return response;
		
		
	}
	
	public RestResponseData listComment(String param) {
		
		RestResponseData response = new RestResponseData();
		CommentSpecification spec = null;
		
		
		if (param != null && !param.isEmpty()) {
			spec = new CommentSpecification();	
			spec.add(param);
		}
		
		List<Comments> commentLs = commentRepository.findAll(spec);
		commentLs.sort(Comparator.comparing(Comments::getId));	
		response.setData(commentLs);
		
		return response;
		
		
	}
}
