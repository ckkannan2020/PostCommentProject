package com.commentpost;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.orm.jpa.EntityManagerFactoryBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableMBeanExport;
import org.springframework.context.annotation.Primary;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.jmx.support.RegistrationPolicy;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;



@Configuration
@EnableJpaRepositories(basePackages = "com.commentpost.repository", entityManagerFactoryRef = "commentEntityManagerFactory", 
			transactionManagerRef = "commentTransactionManager")
@EnableTransactionManagement
@EnableMBeanExport(registration=RegistrationPolicy.IGNORE_EXISTING)
public class CommentDatasourceConfiguration {
	private static final Logger logger = LoggerFactory.getLogger(CommentDatasourceConfiguration.class);

	@Bean
	@ConfigurationProperties(prefix = "spring.comment-datasource")
	@Primary
	public JndiPropertyHolder primary() {
		return new JndiPropertyHolder();
	}

	@Bean(name = "comDS")
	@Primary
	public DataSource commentDataSource() {
		JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
		DataSource dataSource = dataSourceLookup.getDataSource(primary().getJndiName());
		logger.info("datasource"+dataSource.toString());
		return dataSource;
	}

	@Bean
	@Primary																		
	public LocalContainerEntityManagerFactoryBean commentEntityManagerFactory(final EntityManagerFactoryBuilder builder) {
		return builder
				.dataSource(commentDataSource())
				.packages("com.commentpost")
				.persistenceUnit("commentPersistenceUnit")
				.build();
	}

	@Bean
	@Primary
	public JpaTransactionManager commentTransactionManager(@Qualifier("commentEntityManagerFactory") final EntityManagerFactory factory) {
		return new JpaTransactionManager(factory);
	}

	private static class JndiPropertyHolder {
		private String jndiName;

		public String getJndiName() {
			return jndiName;
		}

		public void setJndiName(String jndiName) {
			this.jndiName = jndiName;
		}
	}
	
}
