package com.commentpost.web;

import java.io.IOException;
import java.io.StringWriter;

import javax.persistence.Convert;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.commentpost.bean.RestCommentParams;
import com.commentpost.bean.RestParams;
import com.commentpost.bean.RestPostId;
import com.commentpost.bean.RestResponse;
import com.commentpost.bean.RestResponseData;
import com.commentpost.service.CommentService;
import com.commentpost.service.PostService;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.jsonFormatVisitors.JsonAnyFormatVisitor;

@RestController
@RequestMapping("/api")
public class CommentPostController {
	
	@Autowired
	CommentService commentService;
	
	@Autowired
	PostService postService;
	
	


	
	@PostMapping(path="/insert/comment", produces="application/json")
	public ResponseEntity<String> insertComment(@RequestBody RestParams params){
		String res =null;
		RestResponseData response = new RestResponseData();
		
		response = commentService.insertComment(params);
		
		res = responseJson(response);
		
		return new ResponseEntity<String> (res,HttpStatus.OK);
		
	}
	
	@PostMapping(path="/insert/post", produces="application/json")
	public ResponseEntity<String> insertPost(@RequestBody RestParams params){
		String res =null;
		RestResponseData response = new RestResponseData();
		
		response = postService.insertPost(params);
		
		res = responseJson(response);
		
		return new ResponseEntity<String> (res,HttpStatus.OK);		
	}
	
//	@GetMapping(path="/list/comments", produces="application/json")
	@GetMapping(path="/list/comments/{search}", produces="application/json")
	public ResponseEntity<String> getComments(@PathVariable String search){
		
		String res =null;
		RestResponseData response = new RestResponseData();
		response = commentService.listComment(search);		
		res = responseJson(response);
		return new ResponseEntity<String> (res,HttpStatus.OK);
	}
	
	
	@GetMapping(path="/list/comments", produces="application/json")
	public ResponseEntity<String> getCommentsAll(){
		
		String res =null;
		RestResponseData response = new RestResponseData();		
		response = commentService.listCommentAll();
		res = responseJson(response);
		return new ResponseEntity<String> (res,HttpStatus.OK);
	}
	
	
	
	@GetMapping(path="/list/posts", produces="application/json")
	public ResponseEntity<String> getPostsAll(){
		
		String res =null;
		RestResponseData response = new RestResponseData();
		
		response = postService.listPostsAll();
		res = responseJson(response);
		return new ResponseEntity<String> (res,HttpStatus.OK);
	}	
	
	@GetMapping(path="/list/posts/{postId}", produces="application/json")
	public ResponseEntity<String> getPosts(@PathVariable Integer postId){
		
		String res =null;
		RestResponseData response = new RestResponseData();
		
		response = postService.listPosts(postId);
		res = responseJson(response);
		return new ResponseEntity<String> (res,HttpStatus.OK);
	}		
	
	String responseJson(RestResponseData params) {
		
		RestResponse resp = new RestResponse() ;

		  String res = "";
		  
		  try {
		      final StringWriter sw = new StringWriter();
		      final ObjectMapper mapper = new ObjectMapper();
		      mapper.writeValue(sw, params.getData());
		      res = sw.toString(); 
		      
		      sw.close();
		  } catch (IOException ex) {
		     System.out.println("Exception"+ ex.getMessage());
		  }

		  return res;		
			
		}	

	

}
